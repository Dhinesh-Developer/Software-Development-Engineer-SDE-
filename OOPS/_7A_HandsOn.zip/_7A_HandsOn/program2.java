package com._7A_HandsOn;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class program2 {

	public static void main(String[] args) {
		
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> squaredList = numbers.stream()
                                           .map(n -> n * n)
                                           .collect(Collectors.toList());
        System.out.println("Squared List: " + squaredList);

        System.out.println("-----------------------------");

        List<String> names = Arrays.asList("Sam", "John", "Sara", "Mike", "Steve", "Alice");
        List<String> startsWithS = names.stream()
                                        .filter(s -> s.startsWith("S"))
                                        .collect(Collectors.toList());
        System.out.println("Names starting with S: " + startsWithS);

        System.out.println("-----------------------------");

        List<String> sortedNames = names.stream()
                                        .sorted()
                                        .collect(Collectors.toList());
        System.out.println("Sorted Names: " + sortedNames);

        System.out.println("-----------------------------");

        List<Integer> numsWithDuplicates = Arrays.asList(1, 2, 2, 3, 4, 4, 5);
        Set<Integer> squaredSet = numsWithDuplicates.stream()
                                                    .map(n -> n * n)
                                                    .collect(Collectors.toSet());

        System.out.println("Squared Set values:");
        squaredSet.forEach(System.out::println);
	}

}
