package com._7A_HandsOn;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.stream.Collectors;


class Product{

	private int ID;
	private String name;
	private String category;
	private String brand;
	private double price;
	private int quantity;
	private int unitsSole;
	private LocalDate createdDate;


	public Product(int iD, String name, String categotry, String brand, double price, int quantity, int unitsSole,
			LocalDate createdDate) {
		super();
		ID = iD;
		this.name = name;
		this.category = categotry;
		this.brand = brand;
		this.price = price;
		this.quantity = quantity;
		this.unitsSole = unitsSole;
		this.createdDate = createdDate;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getUnitsSole() {
		return unitsSole;
	}
	public void setUnitsSole(int unitsSole) {
		this.unitsSole = unitsSole;
	}
	public LocalDate getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}
	@Override
	public String toString() {
		return "Product [ID=" + ID + ", name=" + name + ", categotry=" + category + ", brand=" + brand
				+ ", price=" + price + ", quantity=" + quantity + ", unitsSole=" + unitsSole + ", createdDate="
				+ createdDate + "]";
	}

	public Product() {
	}

}

public class RetailInventoryManagementSystem {

	public static void main(String[] args) {

		List<Product> li = new ArrayList<>();

		li.add(new Product(1, "iPhone 13", "Mobile", "Apple", 69999.00, 20, 150, LocalDate.of(2024, 5, 1)));
		li.add(new Product(2, "Galaxy S22", "Mobile", "Samsung", 64999.00, 15, 120, LocalDate.of(2024, 6, 15)));
		li.add( new Product(3, "Dell Inspiron 15", "Laptop", "Dell", 55999.00, 10, 70, LocalDate.of(2024, 4, 10)));
		li.add(new Product(4, "MacBook Air M2", "Laptop", "Apple", 99999.00, 5, 90, LocalDate.of(2024, 7, 1)));
		li.add(new Product(5, "Sony WH-1000XM4", "Headphones", "Sony", 19999.00, 30, 200, LocalDate.of(2024, 3, 20)));
		li.add(new Product(6, "HP Pavilion x360", "Laptop", "HP", 49999.00, 12, 40, LocalDate.of(2024, 5, 10)));
		li.add(new Product(7, "OnePlus Nord CE", "Mobile", "OnePlus", 24999.00, 25, 100, LocalDate.of(2024, 4, 5)));
		li.add(new Product(8, "Lenovo Tab M10", "Tablet", "Lenovo", 17999.00, 18, 60, LocalDate.of(2024, 6, 1)));
		li.add(new Product(9, "Samsung Galaxy Tab A7", "Tablet", "Samsung", 20999.00, 20, 80, LocalDate.of(2024, 6, 20)));
		li.add(new Product(10, "Realme Buds Air 3", "Headphones", "Realme", 3999.00, 50, 250, LocalDate.of(2024, 2, 28)));

		System.out.println("List of Products");
		System.out.println(li);

		System.out.println("1. Filter High- Priced products");
		// 1. Filter High- Priced products
		List<Product> res1 = li.stream().filter(x -> x.getPrice()>50000).collect(Collectors.toList());
		res1.forEach(x -> System.out.println(x));
		System.out.println("-------------------------------------");

		System.out.println("2. Sort By price ->descending order");
		// 2. Sort By price ->descending order.
		List<Product> res2 = li.stream().sorted(Comparator.comparingDouble(x1 -> ((Product) x1).getPrice()).reversed()).collect(Collectors.toList());
		res2.forEach(x -> System.out.println(x));
		System.out.println("-------------------------------------");

		System.out.println("3. Highest-price products.");
		//3. Highest-price products.
		Product res3 = li.stream().max((x1,x2) -> x1.getPrice()>x2.getPrice()?1:-1).get();
		System.out.println(res3);
		System.out.println("-------------------------------------");

		System.out.println("5. Group Products by category and show count");
		// 5. Group Products by category and show count
		Map<String, List<Product>> groupedByCategory = li.stream()
				.collect(Collectors.groupingBy(Product::getCategory));

		groupedByCategory.forEach((category, products) -> {
			System.out.println("Category: " + category + " | Count: " + products.size());
			products.forEach(System.out::println);
		});

		System.out.println("-------------------------------------");


		System.out.println("6. Map Brand to Product Names");
		// 6. Map Brand to Product Names
		Map<String, List<String>> brandToProductNames = li.stream()
				.collect(Collectors.groupingBy(
						Product::getBrand,
						Collectors.mapping(Product::getName, Collectors.toList())
						));

		brandToProductNames.forEach((brand, names) -> 
		System.out.println("Brand: " + brand + " -> Products: " + names)
				);
		System.out.println("-------------------------------------");


		System.out.println("Detected low stock quantity");
		// 7. Detect Low stock Items 
		List<Product> res7 = li.stream().filter(x -> x.getQuantity() <=5).collect(Collectors.toList());
		res7.forEach(x -> System.out.println(x));
		System.out.println("-------------------------------------");


		System.out.println("Compute average product price.");
		//8. Compute average product price.
		OptionalDouble res8 = li.stream().mapToDouble(x -> x.getPrice()).average();
		System.out.println(res8);
		System.out.println("-------------------------------------");

		System.out.println("9. Identity Top 3 best sellers.");
		//9. Identity Top 3 best sellers.
		List<Product> res9 = li.stream().sorted(Comparator.comparingInt(x -> x.getUnitsSole())).limit(3).collect(Collectors.toList());
		res9.forEach(x -> System.out.println(x));
		System.out.println("-------------------------------------");

		System.out.println("11. Find products by category and price Range.");
		//11. Find products by category and price Range.
		List<Product> res10= li.stream().filter(x -> x.getCategory().equals("Laptop") && (x.getPrice()>40000 && x.getPrice()<80000)).collect(Collectors.toList());
		res10.forEach(x -> System.out.println(x));
		System.out.println("-------------------------------------");

		System.out.println("12. find unit sold is less than 0.");
		// 12. find unit sold is less than 10.
		List<Product> res11 = li.stream().filter(x -> x.getUnitsSole()==0).collect(Collectors.toList());
		res11.forEach(x -> System.out.println(x));
		System.out.println("-------------------------------------");


		System.out.println("18. Sort Products Alphabetically by Name.");
		//18. Sort Products Alphabetically by Name 
		List<Product> res18 = li.stream().sorted(Comparator.comparing(Product::getName)).collect(Collectors.toList());
		res18.forEach(x -> System.out.println(x));
		System.out.println("-------------------------------------");

		System.out.println("15. List unique product categories.");
		// 15. List unique product categories.
		List<String> res15 = li.stream().map(x -> x.getCategory()).distinct().collect(Collectors.toList());
		res15.forEach(x -> System.out.println(x));
		System.out.println("-------------------------------------");


		System.out.println("13. Count Products per brand.");
		//13. Count Products per brand.
		Long res13 = li.stream().map(x -> x.getBrand()).distinct().count();
		System.out.println(res13);
		System.out.println("-------------------------------------");

		System.out.println("16. Check if all products are in stock.");
		// 16. Check if all products are in stock.
		boolean res16 = li.stream().allMatch(x -> x.getQuantity()>0);
		System.out.println(res16);
		System.out.println("-------------------------------------");


		System.out.println("19. Group products by brand and count units sold");
		// 19. Group products by brand and count units sold
		Map<String, List<Integer>> res19 = li.stream().collect(Collectors.groupingBy(
				Product::getBrand,
				Collectors.mapping(Product::getUnitsSole, Collectors.toList())));
		res19.forEach((brand,unitsSold) -> System.out.println(brand+" "+unitsSold));
		System.out.println("-------------------------------------");


		System.out.println("17. Generate Summary Statistics for Product Prices");
		// 17. Generate Summary Statistics for Product Prices 
		DoubleSummaryStatistics res17 =  li.stream().mapToDouble(x -> x.getPrice()).summaryStatistics();
		System.out.println("Count : "+res17.getCount());
		System.out.println("Minimum : "+res17.getMin());
		System.out.println("Maximum : "+res17.getMax());
		System.out.println("Average : "+res17.getAverage());
		System.out.println("Sum : "+res17.getSum());
		System.out.println("-------------------------------------");

		System.out.println("20. Most recently added");
		// 20. Most recently added
		Product mostRecentProduct = li.stream()
				.max(Comparator.comparing(Product::getCreatedDate))
				.orElse(null);

		if (mostRecentProduct != null) {
			System.out.println("Most recently added product:");
			System.out.println(mostRecentProduct);
		}
		System.out.println("-------------------------------------");

		System.out.println("Maximum Product");
		// 14.Find the Product with the highest stock Value.
		double maximum = 0.0;
		for(Product x : li) {
			double max = x.getPrice() * x.getQuantity();
			maximum = Math.max(maximum, max);
		}
		System.out.println("Maximum "+ maximum);
		System.out.println("-------------------------------------");


		System.out.println("4. Calculate Total Inventory Worth");
		// 4. Calculate Total Inventory Worth
		double totalInventoryWorth = li.stream()
				.mapToDouble(p -> p.getPrice() * p.getQuantity())
				.sum();

		System.out.println("Total Inventory Worth: " + totalInventoryWorth);
		System.out.println("-------------------------------------");

		
		System.out.println("10. Calculate Total Inventory Worth");
		// 10. Fetch Recently Added Products (last 60 days)
		LocalDate sixtyDaysAgo = LocalDate.now().minusDays(60);

		List<Product> recentProducts = li.stream()
		        .filter(p -> p.getCreatedDate().isAfter(sixtyDaysAgo))
		        .collect(Collectors.toList());

		System.out.println("Products added in the last 60 days:");
		recentProducts.forEach(System.out::println);

		System.out.println("-------------------------------------");

	} 

}
