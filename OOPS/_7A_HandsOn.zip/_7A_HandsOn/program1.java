package com._7A_HandsOn;

import java.util.stream.Stream;

public class program1 {

	public static void main(String[] args) {
		
		System.out.println("First 5 numbers divisible by 5:");
        
        Stream.iterate(1, n -> n+1)
        .filter(n -> n%5==0)
        .limit(5)
        .forEach(System.out::println);
        
	}

}
