package com._10HandsOn;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;
import java.util.Set;

public class DateTimeExercises {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 1a) Age Calculator
        System.out.print("Enter your birthdate (yyyy-MM-dd): ");
        LocalDate birthDate = LocalDate.parse(sc.nextLine());
        LocalDate today = LocalDate.now();
        Period age = Period.between(birthDate, today);
        System.out.println("Your age is: " + age.getYears() + " years");

        // 1b) End of Month Date
        LocalDate endOfMonth = today.with(TemporalAdjusters.lastDayOfMonth());
        System.out.println("Last date of current month: " + endOfMonth);

        // 1c) Custom Date Creation
        System.out.print("Enter year: ");
        int year = sc.nextInt();
        System.out.print("Enter month: ");
        int month = sc.nextInt();
        System.out.print("Enter day: ");
        int day = sc.nextInt();
        LocalDate customDate = LocalDate.of(year, month, day);
        System.out.println("Custom Date: " + customDate);

        // 1d) Days Until Event (New Year)
        LocalDate newYear = LocalDate.of(today.getYear() + 1, 1, 1);
        long daysUntilNewYear = ChronoUnit.DAYS.between(today, newYear);
        System.out.println("Days until New Year: " + daysUntilNewYear);

        // 1e) Is It Weekend?
        DayOfWeek dayOfWeek = today.getDayOfWeek();
        boolean isWeekend = (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY);
        System.out.println("Is today weekend? " + isWeekend);

        // 1f) First Monday of Next Month
        LocalDate firstMondayNextMonth = today.with(TemporalAdjusters.firstDayOfNextMonth())
                                              .with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY));
        System.out.println("First Monday of next month: " + firstMondayNextMonth);

        // 2a) Midnight and Noon
        LocalTime midnight = LocalTime.MIDNIGHT;
        LocalTime noon = LocalTime.NOON;
        System.out.println("Midnight: " + midnight + ", Noon: " + noon);
        System.out.println("Is Midnight before Noon? " + midnight.isBefore(noon));

        // 2b) Time Formatter 12-hour format
        LocalTime now = LocalTime.now();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");
        System.out.println("Current Time (12-hour format): " + now.format(timeFormatter));

        // 2c) Schedule Alarm
        System.out.print("Enter wake-up time (HH:mm): ");
        sc.nextLine(); 
        LocalTime wakeUp = LocalTime.parse(sc.nextLine());
        System.out.print("Enter sleep duration in hours: ");
        int sleepHours = sc.nextInt();
        LocalTime bedTime = wakeUp.minusHours(sleepHours);
        System.out.println("You should go to bed at: " + bedTime);

        // 2d) Time Adjustment (-45 minutes)
        LocalTime adjustedTime = now.minusMinutes(45);
        System.out.println("Current time minus 45 minutes: " + adjustedTime);

        // 3a) Time Travel
        LocalDateTime nowDateTime = LocalDateTime.now();
        LocalDateTime futureDateTime = nowDateTime.plusYears(1).plusMonths(3).plusDays(7);
        System.out.println("After 1 year, 3 months, 7 days: " + futureDateTime);

        // 3b) DateTime Difference
        LocalDateTime anotherDateTime = nowDateTime.plusHours(5).plusMinutes(30);
        long hoursBetween = ChronoUnit.HOURS.between(nowDateTime, anotherDateTime);
        long minutesBetween = ChronoUnit.MINUTES.between(nowDateTime, anotherDateTime);
        System.out.println("Difference: " + hoursBetween + " hours, " + minutesBetween + " minutes");

        // 3c) Is Working Hour?
        LocalTime meetingTime = LocalTime.of(15, 0); 
        boolean isWorkingHour = !meetingTime.isBefore(LocalTime.of(9, 0)) && !meetingTime.isAfter(LocalTime.of(18, 0));
        System.out.println("Is meeting within working hours? " + isWorkingHour);

        // 4a) Meeting Across Zones
        ZonedDateTime meetingIST = ZonedDateTime.of(LocalDate.now(), LocalTime.of(10, 0), ZoneId.of("Asia/Kolkata"));
        ZonedDateTime meetingLondon = meetingIST.withZoneSameInstant(ZoneId.of("Europe/London"));
        System.out.println("10 AM IST in London: " + meetingLondon.toLocalTime());

        // 4b) Flight Duration
        ZonedDateTime departure = ZonedDateTime.of(LocalDate.now(), LocalTime.of(22, 0), ZoneId.of("Asia/Kolkata"));
        ZonedDateTime arrival = departure.withZoneSameInstant(ZoneId.of("America/New_York")).plusHours(14); // flight takes 14h
        Duration flightDuration = Duration.between(departure, arrival);
        System.out.println("Flight Duration: " + flightDuration.toHours() + " hours");

        // 4c) List Zone IDs
        Set<String> zoneIds = ZoneId.getAvailableZoneIds();
        System.out.println("Available Zone IDs: " + zoneIds);

        // 5a) Period Between Dates
        LocalDate startDate = LocalDate.of(2025, 1, 1);
        LocalDate endDate = LocalDate.of(2025, 7, 26);
        Period period = Period.between(startDate, endDate);
        System.out.println("Months: " + period.getMonths() + ", Days: " + period.getDays());

        // 5b) Duration Between Times
        LocalTime time1 = LocalTime.of(10, 0, 0);
        LocalTime time2 = LocalTime.of(12, 30, 0);
        Duration duration = Duration.between(time1, time2);
        System.out.println("Seconds between times: " + duration.getSeconds());

        // 5c) Birthday Countdown
        LocalDate nextBirthday = birthDate.withYear(today.getYear());
        if (nextBirthday.isBefore(today)) {
            nextBirthday = nextBirthday.plusYears(1);
        }
        Period untilBirthday = Period.between(today, nextBirthday);
        System.out.println("Days until next birthday: " + untilBirthday.getDays());

        // 5d) Custom Date Formatting
        DateTimeFormatter customFormatter = DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy");
        System.out.println("Formatted date: " + endDate.format(customFormatter));

        sc.close();
    }
}
