package com._9HandsOn;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;

public class DateTimeHandsOn {

    public static void main(String[] args) {
        
        // 1(a) Check Leap Year
        int year = 2024;
        boolean isLeap = LocalDate.of(year, 1, 1).isLeapYear();
        System.out.println(year + " is Leap Year? " + isLeap);

        // 1(b) Day of Week Finder
        LocalDate birthday = LocalDate.of(2000, 5, 15);
        System.out.println("Birthday Day of Week: " + birthday.getDayOfWeek());

        // 1(c) Date Comparison
        LocalDate givenDate = LocalDate.of(2030, 1, 1);
        LocalDate today = LocalDate.now();
        if (givenDate.isAfter(today))
            System.out.println("Given date is in the future.");
        else if (givenDate.isBefore(today))
            System.out.println("Given date is in the past.");
        else
            System.out.println("Given date is today.");

        // 1(d) Add/Subtract Days
        System.out.println("Today + 30 days: " + today.plusDays(30));

        // 1(e) Find Next Tuesday
        LocalDate nextTuesday = today.with(TemporalAdjusters.next(DayOfWeek.TUESDAY));
        System.out.println("Next Tuesday: " + nextTuesday);

        // 2(a) Current Time Display
        LocalTime nowTime = LocalTime.now();
        System.out.println("Current Time: " + nowTime.format(DateTimeFormatter.ofPattern("HH:mm:ss")));

        // 2(b) Time Difference
        LocalTime lunchTime = LocalTime.of(13, 0);
        long minutesUntilLunch = ChronoUnit.MINUTES.between(nowTime, lunchTime);
        System.out.println("Minutes until lunch: " + minutesUntilLunch);

        // 2(c) Add Time
        System.out.println("Current Time + 1hr 15min: " + nowTime.plusHours(1).plusMinutes(15));

        // 2(d) Compare Times
        LocalTime givenTime = LocalTime.of(18, 0);
        if (givenTime.isAfter(nowTime))
            System.out.println("Given time is after now.");
        else
            System.out.println("Given time is before now.");

        // 3(a) Combine Date and Time
        LocalDateTime dateTime = LocalDateTime.of(today, nowTime);
        System.out.println("Combined DateTime: " + dateTime);

        // 3(b) Calculate Duration
        LocalDateTime start = LocalDateTime.of(2025, 8, 1, 9, 0);
        LocalDateTime end = LocalDateTime.of(2025, 8, 1, 17, 0);
        long hoursBetween = ChronoUnit.HOURS.between(start, end);
        System.out.println("Hours between start and end: " + hoursBetween);

        // 3(c) Schedule a Meeting
        LocalDateTime meetingStart = LocalDateTime.of(2025, 8, 14, 10, 0);
        LocalDateTime meetingEnd = meetingStart.plusDays(3).plusHours(5);
        System.out.println("Meeting after 3 days & 5 hours: " + meetingEnd);

        // 4(a) Time in Another Zone
        ZonedDateTime tokyoTime = ZonedDateTime.now(ZoneId.of("Asia/Tokyo"));
        ZonedDateTime newYorkTime = ZonedDateTime.now(ZoneId.of("America/New_York"));
        System.out.println("Tokyo Time: " + tokyoTime);
        System.out.println("New York Time: " + newYorkTime);

        // 4(b) Convert to UTC
        ZonedDateTime utcTime = ZonedDateTime.now(ZoneId.of("UTC"));
        System.out.println("UTC Time: " + utcTime);

        // 5 Format and Parse Dates
        String formattedDate = today.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        System.out.println("Formatted Date: " + formattedDate);

        LocalDate parsedDate = LocalDate.parse(formattedDate, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        System.out.println("Parsed Date: " + parsedDate);
    }
}
/* Output.
2024 is Leap Year? true
Birthday Day of Week: MONDAY
Given date is in the future.
Today + 30 days: 2025-09-13
Next Tuesday: 2025-08-19
Current Time: 19:51:14
Minutes until lunch: -411
Current Time + 1hr 15min: 21:06:14.459064700
Given time is before now.
Combined DateTime: 2025-08-14T19:51:14.459064700
Hours between start and end: 8
Meeting after 3 days & 5 hours: 2025-08-17T15:00
Tokyo Time: 2025-08-14T23:21:14.464064200+09:00[Asia/Tokyo]
New York Time: 2025-08-14T10:21:14.465065300-04:00[America/New_York]
UTC Time: 2025-08-14T14:21:14.466087900Z[UTC]
Formatted Date: 14-08-2025
Parsed Date: 2025-08-14
 * */
