package _8HandsOn;

import java.util.*;
import java.util.stream.Collectors;

class Flight {
    String flightNo;
    String destination;
    double duration;
    String airline;
    double fare;

    public Flight(String flightNo, String destination, double duration, String airline, double fare) {
        this.flightNo = flightNo;
        this.destination = destination;
        this.duration = duration;
        this.airline = airline;
        this.fare = fare;
    }

    @Override
    public String toString() {
        return String.format("[%s | %s | %.1f hrs | %s | $%.2f]", 
                flightNo, destination, duration, airline, fare);
    }
}

public class program9 {
    public static void main(String[] args) {
        List<Flight> flights = Arrays.asList(
                new Flight("F101", "Paris", 7.5, "AirFrance", 450),
                new Flight("F102", "Paris", 8.0, "Lufthansa", 420),
                new Flight("F103", "London", 6.0, "BritishAirways", 500),
                new Flight("F104", "London", 5.5, "AirIndia", 480),
                new Flight("F105", "Paris", 7.5, "Emirates", 420)
        );

        Map<String, List<Flight>> result = flights.stream()
                .collect(Collectors.groupingBy(
                        f -> f.destination,
                        Collectors.collectingAndThen(
                                Collectors.toList(),
                                list -> list.stream()
                                        .sorted(
                                                Comparator.comparingDouble((Flight f) -> f.fare)
                                                        .thenComparingDouble(f -> f.duration)
                                        )
                                        .collect(Collectors.toList())
                        )
                ));

        result.forEach((destination, sortedFlights) -> {
            System.out.println(destination + " → " + sortedFlights);
        });
    }
}
/*London → [[F104 | London | 5.5 hrs | AirIndia | $480.00], [F103 | London | 6.0 hrs | BritishAirways | $500.00]]
Paris → [[F105 | Paris | 7.5 hrs | Emirates | $420.00], [F102 | Paris | 8.0 hrs | Lufthansa | $420.00], [F101 | Paris | 7.5 hrs | AirFrance | $450.00]]

 * */
