package _8HandsOn;

import java.util.*;
import java.util.stream.Collectors;

class Student {
    private int id;
    private String name;
    private double marks;
    private String className;
    private String gender;

    public Student(int id, String name, double marks, String className, String gender) {
        this.id = id;
        this.name = name;
        this.marks = marks;
        this.className = className;
        this.gender = gender;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getMarks() { return marks; }
    public String getClassName() { return className; }
    public String getGender() { return gender; }

    @Override
    public String toString() {
        return name + " (" + className + ", " + gender + ", " + marks + ")";
    }
}

public class program5 {
    public static void main(String[] args) {
        List<Student> students = Arrays.asList(
            new Student(1, "Alice", 82, "ClassA", "Female"),
            new Student(2, "Bob", 78, "ClassA", "Male"),
            new Student(3, "Charlie", 70, "ClassA", "Male"),
            new Student(4, "David", 88, "ClassB", "Male"),
            new Student(5, "Eva", 91, "ClassB", "Female"),
            new Student(6, "Frank", 76, "ClassB", "Male"),
            new Student(7, "Grace", 95, "ClassA", "Female"),
            new Student(8, "Helen", 80, "ClassC", "Female")
        );

        Map<String, Map<String, Double>> result = students.stream()
            .filter(s -> s.getMarks() > 75)
            .collect(Collectors.groupingBy(
                Student::getClassName, 
                Collectors.groupingBy(
                    Student::getGender, 
                    Collectors.averagingDouble(Student::getMarks)
                )
            ));

        result.forEach((className, genderMap) -> {
            System.out.println("Class: " + className);
            genderMap.forEach((gender, avgMarks) ->
                System.out.println("  " + gender + ": " + avgMarks)
            );
        });
    }
}
