package _8HandsOn;

import java.util.*;
import java.util.stream.*;

class Product1 {
    String name;
    double price;
    int unitsSold;

    public Product1(String name, double price, int unitsSold) {
        this.name = name;
        this.price = price;
        this.unitsSold = unitsSold;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getUnitsSold() { return unitsSold; }

    @Override
    public String toString() {
        return name + " ($" + price + ", sold: " + unitsSold + ")";
    }
}

public class program10 {
    public static void main(String[] args) {
        List<Product1> products = Arrays.asList(
            new Product1("Laptop", 800.0, 50),
            new Product1("Phone", 500.0, 120),
            new Product1("Tablet", 300.0, 80),
            new Product1("Headphones", 100.0, 200)
        );

        DoubleSummaryStatistics stats = products.stream()
                .collect(Collectors.summarizingDouble(Product1::getPrice));

        double totalRevenue = products.stream()
                .mapToDouble(p -> p.getPrice() * p.getUnitsSold())
                .sum();

        Product1 minProduct = products.stream()
                .min(Comparator.comparingDouble(Product1::getPrice))
                .orElse(null);

        Product1 maxProduct = products.stream()
                .max(Comparator.comparingDouble(Product1::getPrice))
                .orElse(null);

        System.out.println("Product Statistics:");
        System.out.println("Total Revenue: " + totalRevenue);
        System.out.println("Average Price: " + stats.getAverage());
        System.out.println("Min Priced Product: " + minProduct);
        System.out.println("Max Priced Product: " + maxProduct);
        System.out.println("Count of Products: " + stats.getCount());
    }
}
/*
Product Statistics:
Total Revenue: 144000.0
Average Price: 425.0
Min Priced Product: Headphones ($100.0, sold: 200)
Max Priced Product: Laptop ($800.0, sold: 50)
Count of Products: 4
*/
