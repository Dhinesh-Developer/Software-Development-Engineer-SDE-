package _8HandsOn;

import java.util.*;

class Product {
    private int id;
    private String name;
    private double price;
    private double rating;
    private String category;
    private String brand;

    public Product(int id, String name, double price, double rating, String category, String brand) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.rating = rating;
        this.category = category;
        this.brand = brand;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public double getRating() { return rating; }
    public String getCategory() { return category; }
    public String getBrand() { return brand; }

    @Override
    public String toString() {
        return String.format("%d - %s (%s) | Rating: %.1f | Price: %.2f | Brand: %s",
                id, name, category, rating, price, brand);
    }
}

public class program1 {

    public static void sortProducts(List<Product> products) {
        products.sort(
            Comparator.comparing(Product::getCategory, String.CASE_INSENSITIVE_ORDER) 
                      .thenComparing(Comparator.comparing(Product::getRating).reversed())
                      .thenComparing(Product::getPrice) 
        );
    }

    public static void main(String[] args) {
        List<Product> productList = new ArrayList<>();
        productList.add(new Product(1, "Laptop", 80000, 4.5, "Electronics", "Dell"));
        productList.add(new Product(2, "Mobile", 30000, 4.7, "Electronics", "Samsung"));
        productList.add(new Product(3, "Shirt", 1500, 4.2, "Clothing", "Levis"));
        productList.add(new Product(4, "Shoes", 2500, 4.8, "Clothing", "Nike"));
        productList.add(new Product(5, "Microwave", 12000, 4.4, "Appliances", "LG"));

        System.out.println("Before Sorting:");
        productList.forEach(System.out::println);

        sortProducts(productList);

        System.out.println("\nAfter Sorting:");
        productList.forEach(System.out::println);
    }
}
/*
 * Before Sorting:
1 - Laptop (Electronics) | Rating: 4.5 | Price: 80000.00 | Brand: Dell
2 - Mobile (Electronics) | Rating: 4.7 | Price: 30000.00 | Brand: Samsung
3 - Shirt (Clothing) | Rating: 4.2 | Price: 1500.00 | Brand: Levis
4 - Shoes (Clothing) | Rating: 4.8 | Price: 2500.00 | Brand: Nike
5 - Microwave (Appliances) | Rating: 4.4 | Price: 12000.00 | Brand: LG

After Sorting:
5 - Microwave (Appliances) | Rating: 4.4 | Price: 12000.00 | Brand: LG
4 - Shoes (Clothing) | Rating: 4.8 | Price: 2500.00 | Brand: Nike
3 - Shirt (Clothing) | Rating: 4.2 | Price: 1500.00 | Brand: Levis
2 - Mobile (Electronics) | Rating: 4.7 | Price: 30000.00 | Brand: Samsung
1 - Laptop (Electronics) | Rating: 4.5 | Price: 80000.00 | Brand: Dell
*/
 