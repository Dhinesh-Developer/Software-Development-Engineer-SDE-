package _8HandsOn;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

class Order {
    private int orderId;
    private int customerId;
    private double orderAmount;
    private String status;
    private LocalDate orderDate;

    public Order(int orderId, int customerId, double orderAmount, String status, LocalDate orderDate) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.orderAmount = orderAmount;
        this.status = status;
        this.orderDate = orderDate;
    }

    public int getOrderId() { return orderId; }
    public int getCustomerId() { return customerId; }
    public double getOrderAmount() { return orderAmount; }
    public String getStatus() { return status; }
    public LocalDate getOrderDate() { return orderDate; }
}

public class program4 {

    public static Map<Integer, Double> getTotalOrderAmountPerCustomer(List<Order> orders) {
        return orders.stream()
                .collect(Collectors.groupingBy(
                        Order::getCustomerId,
                        Collectors.summingDouble(Order::getOrderAmount)
                ));
    }

    public static void main(String[] args) {
        List<Order> orders = Arrays.asList(
                new Order(101, 1, 2500.50, "Delivered", LocalDate.of(2025, 8, 1)),
                new Order(102, 2, 3200.00, "Shipped", LocalDate.of(2025, 8, 2)),
                new Order(103, 1, 1500.00, "Delivered", LocalDate.of(2025, 8, 3)),
                new Order(104, 3, 5000.00, "Pending", LocalDate.of(2025, 8, 4)),
                new Order(105, 2, 1800.75, "Delivered", LocalDate.of(2025, 8, 5))
        );

        Map<Integer, Double> totalPerCustomer = getTotalOrderAmountPerCustomer(orders);
        System.out.println("Total Order Amount per Customer:");
        totalPerCustomer.forEach((custId, total) -> 
            System.out.println("Customer " + custId + ": ₹" + total)
        );

        Optional<Map.Entry<Integer, Double>> maxCustomer = totalPerCustomer.entrySet().stream()
                .max(Map.Entry.comparingByValue());

        maxCustomer.ifPresent(entry -> 
            System.out.println("\nTop Customer: " + entry.getKey() + " with ₹" + entry.getValue())
        );

        Map<Integer, Double> sortedByTotalDesc = totalPerCustomer.entrySet().stream()
                .sorted(Map.Entry.<Integer, Double>comparingByValue().reversed())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));

        System.out.println("\nCustomers Sorted by Total Purchase:");
        sortedByTotalDesc.forEach((custId, total) -> 
            System.out.println("Customer " + custId + ": ₹" + total)
        );
    }
}
/*Total Order Amount per Customer:
Customer 1: ₹4000.5
Customer 2: ₹5000.75
Customer 3: ₹5000.0
 * */
