package _8HandsOn;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

class Transaction {
    private int id;
    private int accountId;
    private String type; 
    private double amount;
    private LocalDate date;

    public Transaction(int id, int accountId, String type, double amount, LocalDate date) {
        this.id = id;
        this.accountId = accountId;
        this.type = type;
        this.amount = amount;
        this.date = date;
    }

    public int getId() { return id; }
    public int getAccountId() { return accountId; }
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public LocalDate getDate() { return date; }

    @Override
    public String toString() {
        return "Transaction{id=" + id + ", accountId=" + accountId +
               ", type='" + type + "', amount=" + amount +
               ", date=" + date + "}";
    }
}

// Helper class to store results per account
class AccountSummary {
    private double totalCredited;
    private Transaction mostRecentTransaction;

    public AccountSummary(double totalCredited, Transaction mostRecentTransaction) {
        this.totalCredited = totalCredited;
        this.mostRecentTransaction = mostRecentTransaction;
    }

    public double getTotalCredited() { return totalCredited; }
    public Transaction getMostRecentTransaction() { return mostRecentTransaction; }

    @Override
    public String toString() {
        return "{Total Credited=" + totalCredited +
               ", Most Recent=" + mostRecentTransaction + "}";
    }
}

public class program6 {
    public static void main(String[] args) {
        List<Transaction> transactions = Arrays.asList(
            new Transaction(1, 101, "CREDIT", 5000, LocalDate.of(2025, 8, 5)),
            new Transaction(2, 101, "DEBIT", 2000, LocalDate.of(2025, 8, 6)),
            new Transaction(3, 102, "CREDIT", 7000, LocalDate.of(2025, 8, 4)),
            new Transaction(4, 101, "CREDIT", 3000, LocalDate.of(2025, 8, 8)),
            new Transaction(5, 102, "CREDIT", 2000, LocalDate.of(2025, 8, 10)),
            new Transaction(6, 103, "CREDIT", 1000, LocalDate.of(2025, 8, 7))
        );

        Map<Integer, AccountSummary> result =
            transactions.stream()
                .filter(t -> "CREDIT".equalsIgnoreCase(t.getType()))
                .sorted(Comparator.comparing(Transaction::getDate).reversed()) 
                .collect(Collectors.groupingBy(
                    Transaction::getAccountId,
                    Collectors.collectingAndThen(
                        Collectors.toList(),
                        list -> {
                            double total = list.stream()
                                               .mapToDouble(Transaction::getAmount)
                                               .sum();
                            Transaction mostRecent = list.get(0); 
                            return new AccountSummary(total, mostRecent);
                        }
                    )
                ));

        result.forEach((accountId, summary) ->
            System.out.println("Account " + accountId + " => " + summary)
        );
    }
}
/*
Account 101 => {Total Credited=8000.0, Most Recent=Transaction{id=4, accountId=101, type='CREDIT', amount=3000.0, date=2025-08-08}}
Account 102 => {Total Credited=9000.0, Most Recent=Transaction{id=5, accountId=102, type='CREDIT', amount=2000.0, date=2025-08-10}}
Account 103 => {Total Credited=1000.0, Most Recent=Transaction{id=6, accountId=103, type='CREDIT', amount=1000.0, date=2025-08-07}}
*/
