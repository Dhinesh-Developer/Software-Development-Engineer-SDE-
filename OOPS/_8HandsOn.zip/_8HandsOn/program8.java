package _8HandsOn;

import java.util.*;
import java.util.stream.*;

class Book {
    String title;
    String author;
    double price;
    double rating;

    public Book(String title, String author, double price, double rating) {
        this.title = title;
        this.author = author;
        this.price = price;
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }
    public double getRating() {
        return rating;
    }
}

public class program8 {
    public static void main(String[] args) {
        List<Book> books = Arrays.asList(
                new Book("Java Basics", "John Doe", 500, 4.8),
                new Book("Python 101", "Jane Smith", 400, 4.2),
                new Book("Spring in Action", "Craig Walls", 700, 4.7),
                new Book("Effective Java", "Joshua Bloch", 650, 4.9),
                new Book("C++ Primer", "Stanley Lippman", 550, 3.9)
        );

        Map<Boolean, Set<String>> partitionedBooks =
                books.stream()
                        .collect(Collectors.partitioningBy(
                                b -> b.getRating() >= 4.5, 
                                Collectors.mapping(
                                        Book::getTitle, 
                                        Collectors.toCollection(TreeSet::new) 
                                )
                        ));

        System.out.println("Highly Rated Books (>= 4.5): " + partitionedBooks.get(true));
        System.out.println("Other Books (< 4.5): " + partitionedBooks.get(false));
    }
}
/*
 * Highly Rated Books (>= 4.5): [Effective Java, Java Basics, Spring in Action]
Other Books (< 4.5): [C++ Primer, Python 101]
*/
