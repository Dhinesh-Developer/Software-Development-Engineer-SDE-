package _8HandsOn;

import java.util.*;
import java.util.stream.*;

class InventoryItem {
    String name;
    int stock;
    double price;
    String supplier;

    public InventoryItem(String name, int stock, double price, String supplier) {
        this.name = name;
        this.stock = stock;
        this.price = price;
        this.supplier = supplier;
    }

    public String getName() { return name; }
    public int getStock() { return stock; }
    public double getPrice() { return price; }
    public String getSupplier() { return supplier; }

    @Override
    public String toString() {
        return name + " (Stock: " + stock + ")";
    }
}

public class program7 {

    public static Map<String, Optional<InventoryItem>> groupBySupplierLowestStock(List<InventoryItem> items) {
        return items.stream()
                .collect(Collectors.groupingBy(
                        InventoryItem::getSupplier,
                        Collectors.minBy(Comparator.comparingInt(InventoryItem::getStock))
                ));
    }

    public static void main(String[] args) {
        List<InventoryItem> inventory = Arrays.asList(
                new InventoryItem("Item A", 50, 12.5, "Supplier1"),
                new InventoryItem("Item B", 20, 15.0, "Supplier1"),
                new InventoryItem("Item C", 10, 8.5, "Supplier2"),
                new InventoryItem("Item D", 30, 10.0, "Supplier2"),
                new InventoryItem("Item E", 5, 20.0, "Supplier3")
        );

        Map<String, Optional<InventoryItem>> result = groupBySupplierLowestStock(inventory);

        result.forEach((supplier, itemOpt) -> 
            System.out.println(supplier + " → " + itemOpt.orElse(null))
        );
    }
}
/*
Supplier1 → Item B (Stock: 20)
Supplier3 → Item E (Stock: 5)
Supplier2 → Item C (Stock: 10)

 * */
