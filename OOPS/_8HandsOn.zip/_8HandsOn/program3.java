package _8HandsOn;

import java.util.*;

class User {
    private int id;
    private String name;
    private String email;
    private boolean isVerified;

    public User(int id, String name, String email, boolean isVerified) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.isVerified = isVerified;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public boolean isVerified() { return isVerified; }

    @Override
    public String toString() {
        return "User{id=" + id + ", name='" + name + "', email='" + email + "', verified=" + isVerified + "}";
    }
}

public class program3 {

    public static Optional<User> findFirstUnverifiedWithBlankEmail(List<User> users) {
        return users.stream()
                .filter(u -> !u.isVerified()) 
                .filter(u -> u.getEmail() == null || u.getEmail().trim().isEmpty()) 
                .findFirst();
    }

    public static void main(String[] args) {
        List<User> userList = Arrays.asList(
                new User(1, "Alice", "alice@example.com", true),
                new User(2, "Bob", null, false),
                new User(3, "Charlie", " ", false),
                new User(4, "David", "david@example.com", false)
        );

        findFirstUnverifiedWithBlankEmail(userList)
            .ifPresentOrElse(
                user -> System.out.println("First matching user: " + user),
                () -> System.out.println("No unverified user with blank/null email found.")
            );
    }
}
//First matching user: User{id=2, name='Bob', email='null', verified=false}
