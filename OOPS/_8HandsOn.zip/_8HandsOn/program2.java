package _8HandsOn;
import java.util.*;
import java.util.stream.Collectors;

class Employee {
    private String name;
    private String department;
    private double salary;
    private String designation;

    public Employee(String name, String department, double salary, String designation) {
        this.name = name;
        this.department = department;
        this.salary = salary;
        this.designation = designation;
    }

    public String getName() { return name; }
    public String getDepartment() { return department; }
    public double getSalary() { return salary; }
    public String getDesignation() { return designation; }

    @Override
    public String toString() {
        return name + " (" + designation + ", ₹" + salary + ")";
    }
}

public class program2 {
    public static void main(String[] args) {

        List<Employee> employees = Arrays.asList(
            new Employee("Alice", "IT", 75000, "Developer"),
            new Employee("Bob", "IT", 80000, "Developer"),
            new Employee("Charlie", "IT", 95000, "Manager"),
            new Employee("David", "HR", 60000, "Recruiter"),
            new Employee("Eve", "HR", 70000, "Manager"),
            new Employee("Frank", "Finance", 85000, "Analyst"),
            new Employee("Grace", "Finance", 90000, "Manager")
        );

        Map<String, Map<String, List<Employee>>> groupedData =
            employees.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment, 
                        Collectors.groupingBy(Employee::getDesignation) 
                ));

        groupedData.forEach((dept, designationMap) -> {
            System.out.println("Department: " + dept);
            designationMap.forEach((designation, empList) -> {
                System.out.println("  " + designation + ": " + empList);
            });
        });
    }
}
/*
 Department: Finance
  Analyst: [Frank (Analyst, ₹85000.0)]
  Manager: [Grace (Manager, ₹90000.0)]
Department: HR
  Manager: [Eve (Manager, ₹70000.0)]
  Recruiter: [David (Recruiter, ₹60000.0)]
Department: IT
  Developer: [Alice (Developer, ₹75000.0), Bob (Developer, ₹80000.0)]
  Manager: [Charlie (Manager, ₹95000.0)]

 * */
