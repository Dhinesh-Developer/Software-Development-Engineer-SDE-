package com.kiot;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

class InvalidProjectCodeException extends Exception{
	private static final long serialVersionUID = 1L;
	
	@Override
	public String getMessage() {
		return "if the project code entered is not valid. ";
	}
	
}

class AssignProject{
	 Scanner in = new Scanner(System.in);
	 private String name;
	 private String projectCode;
	 
	 public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}

	public void acceptInput() {
		 System.out.println("Enter Employee Name: ");
		 name =in.next();
		 System.out.println("Enter Project Code: ");
		 projectCode = in.next();
	 }
	 
	 public void validate() throws InvalidProjectCodeException{
		 List<String> codes = Arrays.asList("P101","P103","P103");
		 
		 if(codes.contains(projectCode)) {
			 System.out.println("Employee "+name+" successfully assigned to project "+projectCode);
		 }else {
			 throw new InvalidProjectCodeException();
		 }
		 
	 }
	 
}

public class ExceptionHandling {
	
	public static void main(String[] args) {
		
		AssignProject ap = new AssignProject();
		
		try {
			ap.acceptInput();
			ap.validate();
		
		}catch(InvalidProjectCodeException exception) {
			System.out.println(exception.getMessage());
		}
		
		
	}

}
/*
Enter Employee Name: 
Rajesh
Enter Project Code: 
P101
Employee Rajesh successfully assigned to project P101
 * */
