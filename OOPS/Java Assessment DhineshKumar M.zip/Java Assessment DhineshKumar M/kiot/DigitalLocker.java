package com.kiot;

import java.util.Scanner;

class PassCodeValidatiion{
	
	 Scanner in = new Scanner(System.in);
	 private int passcode;
	 
	 public void acceptInput() {
		 System.out.println("Enter passcode: ");
		 passcode = in.nextInt();
	 }
	 
	 void countDigit(int n) {
		 int cnt = 0;
		 while(n > 0) {
			 cnt++;
			 n=n/10;
		 }
	 }
	 
	 public void validatePasscode() {
		 
		 int copy = passcode;
//		 int count = (passcode);
		 int sum = 0;
//		 
//		 while(passcode > 0) {
//			 int lastDigit = passcode%10;
//			 sum+= lastDigit*3;
////			 sum += (int)Math.pow(lastDigit, count);
////			 sum+=res;
//			 passcode = passcode/10;
//		 }
		 
		 String number = Integer.toString(passcode);

	        int length = number.length();

	        for (char c : number.toCharArray()) {
	            sum += (int) Math.pow(c - '0', length);
	        }
		 if(sum==copy) {
			 System.out.println("Passcode is a valid Armstrong number.");
			 System.out.println("Access Granted.");
		 }else {
			 System.out.println("Passcode is a not valid Armstrong number.");
			 System.out.println("Access Denied.");
		 }
	 }
}

public class DigitalLocker {

	public static void main(String[] args) {
		
		PassCodeValidatiion pass = new PassCodeValidatiion();
		pass.acceptInput();
		pass.validatePasscode();
		
	}

}