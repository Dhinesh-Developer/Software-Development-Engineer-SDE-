package com.kiot;

import java.util.Scanner;

abstract class Employee{

	private String employeeID;
	private String employeeName;

	abstract double calculateSalary(double x,double y);

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

}

class FullTimeEmployee extends Employee{

	@Override
	double calculateSalary(double salary,double benefits) {
		return salary+benefits;
	}

}

class PartTimeEmployee extends Employee{

	@Override
	double calculateSalary(double hourlyRate, double hourlyWorked) {
		return hourlyRate * hourlyWorked;
	}

}

class validate{
	Scanner in = new Scanner(System.in);
	String _name1,_name2;
	double _baseSalary,_benefits,_rate,_worked;
	void acceptInput() {
		System.out.println("Enter Full-Time Employee details: ");
		System.out.println("Name: ");
		_name1 = in.next();
		System.out.println("Base Salary");
		_baseSalary = in.nextDouble();
		System.out.println("Benefits: ");
		_benefits = in.nextDouble();


		System.out.println();
		System.out.println("Enter Part-Time Employee details: ");
		System.out.println("Name: ");
		_name2 = in.next();
		System.out.println("Base Salary");
		_rate = in.nextDouble();
		System.out.println("Benefits: ");
		_worked = in.nextDouble();
	}

	void calculate() {
		Employee _fullTimeEmployee = new FullTimeEmployee();
		Employee _partTimeEmployee = new PartTimeEmployee();

		double res1 = _fullTimeEmployee.calculateSalary(_benefits, _baseSalary);
		System.out.println("Salary of Full-Time Employee "+_name1+": "+res1);

		double res2 =_partTimeEmployee.calculateSalary(_rate, _worked);
		System.out.println("Salary of Part-Time Employee "+_name2+": "+res2);
	}

}

public class Abstraction {

	public static void main(String[] args) {
		validate v = new validate();
		v.acceptInput();
		v.calculate();

	}

}

/*
Enter Full-Time Employee details: 
Name: 
Rajesh
Base Salary
40000
Benefits: 
8000

Enter Part-Time Employee details: 
Name: 
Priya
Base Salary
500
Benefits: 
40
Salary of Full-Time Employee Rajesh: 48000.0
Salary of Part-Time Employee Priya: 20000.0
*/
