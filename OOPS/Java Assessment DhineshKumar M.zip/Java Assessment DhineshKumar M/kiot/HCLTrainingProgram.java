package com.kiot;

/*
 * HCL wants to keep track of employee IDs registering for a training program.
 * @Author: DhineshKumar M
 * 
 * */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

public class HCLTrainingProgram {

	public static void main(String[] args) {
		
		 
		
		Scanner in = new Scanner(System.in);
		List<Integer> list = new ArrayList<>();
		System.out.println("Enter number of employees: ");
		int noOfEmployees = in.nextInt();
		
		for(int i=1;i<=noOfEmployees;i++) {
			System.out.println("Enter the employee ID "+i+":" );
			int value = in.nextInt();
			list.add(value);
		}
		
		System.out.println("Original employee IDs: ");
		System.out.println(list);
		
		System.out.println("Employee IDs after removing duplicates: ");
		TreeSet<Integer> set = new TreeSet<>(list);
		System.out.println(set);
		
		System.out.print("Total unique employee IDs: "+set.size());
		
		in.close();
		
	}

}
/*
Enter number of employees: 
7
Enter the employee ID 1:
101
Enter the employee ID 2:
102
Enter the employee ID 3:
101
Enter the employee ID 4:
103
Enter the employee ID 5:
102
Enter the employee ID 6:
104
Enter the employee ID 7:
103
Original employee IDs: 
[101, 102, 101, 103, 102, 104, 103]
Employee IDs after removing duplicates: 
[101, 102, 103, 104]
Total unique employee IDs: 4
 * */
