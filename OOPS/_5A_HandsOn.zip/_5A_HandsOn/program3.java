package _5A_HandsOn;

import java.io.*;
import java.util.Scanner;

public class program3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter source file name (with path if needed): ");
            String sourceFile = sc.nextLine();

            System.out.print("Enter the word to replace: ");
            String targetWord = sc.nextLine();

            System.out.print("Enter the replacement word: ");
            String replacementWord = sc.nextLine();

            String destinationFile = "modified.txt";

            BufferedReader br = new BufferedReader(new FileReader(sourceFile));
            BufferedWriter bw = new BufferedWriter(new FileWriter(destinationFile));

            String line;
            while ((line = br.readLine()) != null) {
                String updatedLine = line.replaceAll("\\b" + targetWord + "\\b", replacementWord);
                bw.write(updatedLine);
                bw.newLine();
            }

            br.close();
            bw.close();

            System.out.println("Word replacement complete. Modified file saved as: " + destinationFile);

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
