package _5A_HandsOn;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;

public class program1 {

	public static void main(String[] args) {
		
		String input = ("C:\\Arise_Projects\\DIV - Full stack\\Files\\input.txt");
		
		File files = new File(input);
		int charCnt = 0;
		int wordCnt = 0;
		int lineCnt = 0;
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(files));
			String line;
			while((line=br.readLine()) != null) {
				lineCnt++;
				charCnt += line.length();
				String[] words = line.trim().split("\\s+");
				if(!line.trim().isEmpty()) {
					wordCnt += words.length;
				}
			}
			 System.out.println("Number of characters: " + charCnt);
	            System.out.println("Number of words: " + wordCnt);
	            System.out.println("Number of lines: " + lineCnt);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
/*
Number of characters: 722
Number of words: 106
Number of lines: 32
 * */

}
