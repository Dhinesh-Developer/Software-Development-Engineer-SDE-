package _5A_HandsOn;
import java.io.Serializable;

public class Person1 implements Serializable {
    private static final long serialVersionUID = 1L; 

    private String name;
    private int age;
    private String email;

    public Person1(String name, int age, String email) {
        this.name = name;
        this.age = age;
        this.email = email;
    }

    @Override
    public String toString() {
        return "Person { " +
                "name='" + name + '\'' +
                ", age=" + age +
                ", email='" + email + '\'' +
                " }";
    }
}
