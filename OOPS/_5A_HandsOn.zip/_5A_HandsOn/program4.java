package _5A_HandsOn;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class program4 {

    public static void main(String[] args) {
        String filePath = "C:\\Arise_Projects\\DIV - Full stack\\Files\\input.txt"; 
        
        List<Person1> persons = new ArrayList<>();
        persons.add(new Person1("kavin kumar", 30, "kavin@example.com"));
        persons.add(new Person1("Shrithij kumar", 25, "sri@example.com"));
        persons.add(new Person1("Dhinesh kumar", 40, "kumar@example.com"));

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(persons);
            System.out.println("Serialization complete. Data saved to " + filePath);
        } catch (IOException e) {
            System.err.println("Error during serialization: " + e.getMessage());
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            List<Person1> deserializedPersons = (List<Person1>) ois.readObject();
            System.out.println("Deserialization complete. Data read from " + filePath);

            deserializedPersons.forEach(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error during deserialization: " + e.getMessage());
        }
    }
    /*
Serialization complete. Data saved to C:\Arise_Projects\DIV - Full stack\Files\input.txt
Deserialization complete. Data read from C:\Arise_Projects\DIV - Full stack\Files\input.txt
Person { name='kavin kumar', age=30, email='kavin@example.com' }
Person { name='Shrithij kumar', age=25, email='sri@example.com' }
Person { name='Dhinesh kumar', age=40, email='kumar@example.com' }
*/
}

