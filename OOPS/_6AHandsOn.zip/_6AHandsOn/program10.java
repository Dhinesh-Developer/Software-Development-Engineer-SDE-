package com._6AHandsOn;

import java.util.Arrays;
import java.util.List;

class Notifier{
	
	String sendAlert(String message) {
		return message;
	}
}

public class program10 {

	public static void main(String[] args) {
		
		List<String> li = Arrays.asList("Warning","Error","Success");
		
		Notifier n = new Notifier();
		li.forEach(i -> n.sendAlert("ALERT :"+i));
		
	}

}
