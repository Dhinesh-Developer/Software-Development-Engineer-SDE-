package com._6AHandsOn;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class program4 {

	public static void main(String[] args) {
		
		List<String> li = Arrays.asList("Sita", "Ravi", "Shyam", "Anu", "Suresh");
		List<String> res = li.stream().filter(n-> n.startsWith("S")).collect(Collectors.toList());
		System.out.println(res);
	}

}
