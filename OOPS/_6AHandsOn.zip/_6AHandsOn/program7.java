package com._6AHandsOn;

import java.util.function.Supplier;

class Person{
	Person() {
		System.out.println("Person created");
	}	
}

public class program7 {

	public static void main(String[] args) {
		
		Supplier<Person> person = Person::new;
		person.get();
	}

}
