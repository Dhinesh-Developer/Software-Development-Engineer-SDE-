package com._6AHandsOn;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class program6 {

	public static void main(String[] args) {
		Predicate<String> startsWithA = name -> name.startsWith("A");
		Predicate<String> lengthGreaterThan3 = name -> name.length() > 3;

		Predicate<String> filterCondition = startsWithA.and(lengthGreaterThan3);

		List<String> names = Arrays.asList("Anu", "Amit", "Ajay", "Arjun", "Bob", "Alice", "Amy");

		System.out.println("\n---- Names starting with 'A' and longer than 3 characters ----");
		names.stream()
		.filter(filterCondition)
		.forEach(System.out::println);
	}

}
