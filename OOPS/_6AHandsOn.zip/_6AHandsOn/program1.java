package com._6AHandsOn;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class program1 {

	public static void main(String[] args) {
		
		List<String> li = Arrays.asList(
			"john@gmail.com", "amy@yahoo.com", "raj@gmail.com", 
			 "hello@outlook.com");
		
		List<String> res = li.stream().filter(n -> n.contains("@gmail.com")).collect(Collectors.toList());
		System.out.println(res);
	}

}
