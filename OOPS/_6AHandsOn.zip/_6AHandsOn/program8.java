package com._6AHandsOn;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class program8 {

	public static void main(String[] args) {
		
		
		List<String> li = Arrays.asList("Anu", "Ravi", "Kiran", "Suresh", "Megha");
		List<String> res = li.stream().filter(n -> n.length()>4).map(n-> n.toUpperCase()).collect(Collectors.toList());
		res.forEach(n -> System.out.println(n));
	}

}
