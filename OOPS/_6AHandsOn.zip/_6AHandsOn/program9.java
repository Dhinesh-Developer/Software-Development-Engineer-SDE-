package com._6AHandsOn;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class program9 {

	public static void main(String[] args) {
	
		List<String> li = Arrays.asList("10","20","30");
		List<Integer> res = li.stream().map(n -> Integer.parseInt(n)).collect(Collectors.toList());
		System.out.println(res);
	}

}
