package com._6AHandsOn;

import java.util.*;
import java.util.function.*;

public class program5 {
	public static void main(String[] args) {

		Supplier<Integer> otpSupplier = () -> {
			return 1000 + new Random().nextInt(9000);
		};

		System.out.println("---- 5 Random 4-digit OTPs ----");
		for (int i = 0; i < 5; i++) {
			System.out.println("OTP " + (i + 1) + ": " + otpSupplier.get());
		}


	}
}