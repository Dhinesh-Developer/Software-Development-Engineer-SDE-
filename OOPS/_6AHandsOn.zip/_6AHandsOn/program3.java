package com._6AHandsOn;

@FunctionalInterface
interface SalaryCalculator{
	void calculator(double base,double bonus);
}

public class program3 {

	public static void main(String[] args) {
		
		SalaryCalculator sc = (base,bonus) -> System.out.println("Total Salary: "+base+bonus);
		sc.calculator(100000, 10000);
		
	}

}
